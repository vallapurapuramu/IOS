//
//  DisplayImagesViewController.swift
//  Vallapurapu_TableViewDisplay
//
//  Created by student on 11/19/21.
//

import UIKit

class DisplayImagesViewController: UIViewController {

    @IBOutlet weak var displayLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    var imageName = ""
    var itemName = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        imageView.image = UIImage(named: "\(imageName)")
    }
    
    @IBAction func getInfo(_ sender: Any) {
        
        if itemName == "cars"{
            displayLabel.text = "A car is a wheeled motor vehicle used for transportation. Most definitions of cars say that they run primarily on roads, seat one-to-eight people, have four wheels and mainly transport people rather than goods"
        }
        else if itemName == "fruits"
        {
            displayLabel.text = "In common language usage, fruit normally means the fleshy seed-associated structures (or produce) of plants that typically are sweet or sour and edible in the raw state, such as apples, bananas, grapes, lemons, oranges, and strawberries."
        }
        else{
            displayLabel.text = "A widely circulated story holds that the word gadget was invented when Gaget, Gauthier & Cie, the company behind the repoussé construction of the Statue of Liberty (1886), made a small-scale version of the monument and named it after their firm; however this contradicts the evidence that the word was already used before in nautical circles, and the fact that it did not become popular, at least in the USA, until after World War"
        }
    }
    
    

}
