//
//  ViewController.swift
//  CordinatesDemo
//
//  Created by student on 10/7/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var ImageOutketView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        var minx = ImageOutketView.frame.minX
        var miny = ImageOutketView.frame.minY
        print(minx,miny)
        var maxx = ImageOutketView.frame.maxX
        var maxy = ImageOutketView.frame.maxY
       print(maxx,maxy)
        var midx = ImageOutketView.frame.midX
        var midy = ImageOutketView.frame.midY
       print(midx,midy)
        var height = ImageOutketView.frame.height
        var width = ImageOutketView.frame.width
        
        print(height,",",width)
        //change the location of  the Image view to the bottom right corner
        ImageOutketView.frame.origin.x = 314
        ImageOutketView.frame.origin.y = 796
        //change the location of  the Image view to the bottom left corner
        ImageOutketView.frame.origin.x = 0
        ImageOutketView.frame.origin.y = 718
        
        //change the location of  the Image view to the top right corner
        ImageOutketView.frame.origin.x = 314
            ImageOutketView.frame.origin.y = 0
        //change the location of  the Image view to the  middle
      
            
            ImageOutketView.frame.origin.x = 157
        ImageOutketView.frame.origin.y =  398
        
        
    }
   
    
    @IBAction func SubmitButtonClicked(_ sender: UIButton) {
        //when the submit button is clicked the width and height should be increased by 100 and the imageview must be in the center of the screen
        var height = (ImageOutketView.frame.height)
        height += 100
        var width = (ImageOutketView.frame.width)
        width +=  100
        print(height,width)
        
       var x = ImageOutketView.frame.origin.x-50
    var y = ImageOutketView.frame.origin.y-50
        var imageFrame = CGRect(x : x ,y : y, width: width, height: height)
        //ImageOutketView.frame = imageFrame
//        UIView.animate(withDuration: 1,delay: 3, animations: {
//            self.ImageOutketView.frame = imageFrame
//            self.ImageOutketView.alpha = 1
//        })
        
        
        //with duration will show the result of function after duration
        //delay will give some delay in displaying the image
        UIView.animate(withDuration: 1, delay: 0,
                       //spring damping min value is 1 and max value is 0
                       usingSpringWithDamping: 1,
                //initialspring velocity the min value is 1 and max value is 100
                       //it will give the spring action
                       initialSpringVelocity: 100, animations: {
            self.ImageOutketView.frame = imageFrame
        })
    }
    
}

