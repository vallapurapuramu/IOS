//
//  ViewController.swift
//  Vallapurapu_SearchApp
//
//  Created by student on 10/12/21.
//

import UIKit

class ViewController: UIViewController {
    
          
    @IBOutlet weak var searchTextField: UITextField!
    @IBOutlet weak var searchButtonAction: UIButton!
          
          @IBOutlet weak var resultImage: UIImageView!
          
          @IBOutlet weak var moreImages: UIButton!
          
          @IBOutlet weak var topicInfoText: UITextView!
          
          @IBOutlet weak var resetButton: UIButton!
         
         
          override func viewDidLoad() {
              super.viewDidLoad()
              // Do any additional setup after loading the view.
              moreImages.isHidden=true
              topicInfoText.isHidden=true
              searchButtonAction.isEnabled=false
              resetButton.isHidden=true
              resultImage.image=UIImage(named: topics[5][0])
          }
          var topics = [["actor1","actor2","actor3","actor4","actor5"],["animal1","animal2","animal3","animal4","animal5"],
                        ["flower1","flower2","flower3","flower4","flower5"],
                        ["toy1","toy2","toy3","toy4","toy5"],
                        ["apple1","apple2","apple3","apple4","apple5"],["notfound"]]
                    var actor_keywords = ["actor","hero","movie"]
                    var animals_keywords = ["animal","wild","domestic"]
                    var toy_keywords = ["toys","kids","games"]
                    var flower_keywords = ["beautiful","flowers"]
                    var apple_keywords = ["apple","costly","steve","rich"]


         var topic = 0
          var pic1:Int!
                  var pic2:Int!
                  var pic3:Int!
                  var pic4:Int!
                  var pic5:Int!


          @IBAction func searchButtonAction(_ sender: UIButton) {
                      pic1=0
                      pic2=0
                      pic3=0
                      pic4=0
                      pic5=0
                      moreImages.isHidden=false
                      topicInfoText.isHidden=false
                      resetButton.isHidden=false
                      if(actor_keywords.contains(searchTextField.text!)){
                          moreImages.isEnabled=true
                          
                          resultImage.image=UIImage(named: topics[0][pic1])
                          topic=1
                          topicInfoText.text="According to latest estimates, there are around 8.7 million species on the planet. Animals are thought to make up 1-2 million of those species. And how much do we know about all of these different species? Not a lot! According to the same study, 86% of all land species and 91% of all sea species have yet to be discovered or documented!"
                          
                      }
                      else if(animals_keywords.contains(searchTextField.text!)){
                          moreImages.isEnabled=true
                          resultImage.image=UIImage(named: topics[1][0])
                          topic=2
                          topicInfoText.text="An actor's primary responsibility is to use their voice, body, actions, and reactions to effectively communicate the character they are portraying to an audience. Actors use their art to tell stories, elicit emotional responses from their audience, and provoke thought."
                      }
                      else if(flower_keywords.contains(searchTextField.text!)){
                          moreImages.isEnabled=true
                          resultImage.image=UIImage(named: topics[2][pic2])
                          topic=3
                          topicInfoText.text="The reproductive portion of blooming plants is the flower. Flowers are sometimes known as a plant's bloom or blossom. Petals are found on flowers. The components of the flower that produce pollen and seeds are found within the petals."
                          
                      }
                      else if(toy_keywords.contains(searchTextField.text!)){
                          moreImages.isEnabled=true
                          resultImage.image=UIImage(named: topics[3][pic3])
                          topic=4
                          topicInfoText.text="A car (or automobile) is a motor vehicle with four wheels that is used for transportation. Cars are typically defined as vehicles that drive largely on roadways, seat one to eight people, have four wheels, and primarily transport people rather than cargo, according to most definitions. Driving, parking, passenger comfort, and a variety of lights are all controlled via car controls."
                      }
                      else if(apple_keywords.contains(searchTextField.text!)){
                          moreImages.isEnabled=true
                          resultImage.image=UIImage(named: topics[4][pic4])
                          topic=5
                          topicInfoText.text="A book is a collection of pages (made of papyrus, parchment, vellum, or paper) bound together and covered by a cover that is used to record information in the form of writing or images. Only drawings, engravings, or pictures, crossword puzzles, or cut-out dolls are permitted in books."
                      }
                      else {
                          resultImage.image = UIImage(named: topics[5][pic5])
                          moreImages.isHidden=true
                          topicInfoText.isHidden=true
                          searchButtonAction.isEnabled=true
                      }
                      
          }
          @IBAction func showMoreImagesBtn(_ sender: UIButton) {
                      if(topic==1){
                          pic1+=1
                          updateData(imgNum: pic1)
                        
                      }
                      if(topic==2){
                          
                          pic2+=1
                          updateData(imgNum: pic2)
                      }
                      if(topic==3){
                          
                          pic3+=1
                          updateData(imgNum: pic3)
                      }
                      if(topic==4){
                          
                          pic4+=1
                          updateData(imgNum: pic4)
                      }
                      if(topic==5){
                          
                          pic5+=1
                          updateData(imgNum: 2)
                        moreImages.isEnabled = false
                        moreImages.alpha = 0.5
                        
                        
                        
                      }
                      
                      
          }
          
          func updateData(imgNum: Int){
              if(topic==1){
                          
                          if  pic1 == topics[0].count  {
                              
                              moreImages.isEnabled = false
                            
                              
                          }else{
                              resultImage.image = UIImage(named: topics[0][pic1])
                              
                          }
                      }
                      if(topic==2){
                          if(pic2==topics[1].count){
                              moreImages.isEnabled=false
                           
                          }else{
                              resultImage.image=UIImage(named: topics[1][pic2])
                          }
                      }
                      if(topic==3){
                          if(pic3==topics[2].count){
                              moreImages.isEnabled=false
                            
                          }else{
                              resultImage.image=UIImage(named: topics[2][pic3])
                          }
                          
                      }
                      if(topic==4){
                          if(pic4==topics[3].count){
                              moreImages.isEnabled=false
                            moreImages.alpha = 0.5
                            
                          }else{
                              resultImage.image=UIImage(named: topics[3][pic4])
                          }
                      }
                      if(topic==5){
                          if(pic5==topics[4].count){
                              moreImages.isEnabled=false
                            moreImages.alpha = 0.5
                          }else{
                              resultImage.image=UIImage(named: topics[4][pic5])
                          }
                      }
                      
                 }
          
          
        @IBAction func editingChanged(_ sender: UITextField) {
            let textEnterd = searchTextField.text!
                 if textEnterd.isEmpty{
                      searchButtonAction.isEnabled = false
                    searchButtonAction.alpha = 0.5
                    
                 }
                 else{
                    searchButtonAction.alpha = 1
                     searchButtonAction.isEnabled = true
                }
        }
      
          
          @IBAction func ResetButtonClicked(_ sender: UIButton) {
            
                             topicInfoText.isHidden=true
                             moreImages.isHidden=true
                             searchButtonAction.isHidden=false
                             resetButton.isHidden=true
                             resultImage.image=UIImage(named: topics[5][0])
                             searchTextField.isHidden=false
            searchTextField.text = ""
            
            
            
            
              
          }
    
    
    
   
   
    
  
    
    
          
    }
