//
//  ViewController.swift
//  TableViewDemo
//
//  Created by student on 11/2/21.
//

import UIKit

class Product{
    var productName : String
    var  productCategory : String
    
    init(productName : String, productCategory : String) {
        self.productName = productName
        self.productCategory = productCategory
    }
}


class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return productsArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = TableViewOutlet.dequeueReusableCell(withIdentifier: "ReusableCell", for: indexPath)
        
        //Assign the date to the cell from datasource (array)
        cell.textLabel?.text = productsArray[indexPath.row].productName
        
        return cell
        
    }
    

    @IBOutlet weak var TableViewOutlet: UITableView!
    var productsArray = [Product]()
    override func viewDidLoad() {
        super.viewDidLoad()
        TableViewOutlet.delegate = self
        TableViewOutlet.dataSource = self
       let p1 = Product(productName: "MacBookAir", productCategory: "Laptop")
        productsArray.append(p1)
        let p2 = Product(productName: "iPhone", productCategory: "Mobile")
         productsArray.append(p2)
        let p3 = Product(productName: "AirPodsPro", productCategory: "Music")
         productsArray.append(p3)
        let p4 = Product(productName: "Apple Watch", productCategory: "Accessories")
         productsArray.append(p4)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "ResultSegue"{
            let destination = segue.destination
            as!
            ResultViewController
            destination.product = productsArray[(TableViewOutlet.indexPathForSelectedRow?.row)!]
        }
        
    }


}

