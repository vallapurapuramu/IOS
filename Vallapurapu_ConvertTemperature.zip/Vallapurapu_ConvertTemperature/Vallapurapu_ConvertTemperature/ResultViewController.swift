//
//  ResultViewController.swift
//  Vallapurapu_ConvertTemperature
//
//  Created by student on 11/3/21.
//

import UIKit

class ResultViewController: UIViewController {

    @IBOutlet weak var fahrenheitLabel: UILabel!
    
    @IBOutlet weak var kelvinLabel: UILabel!
    
    @IBOutlet weak var textLabel: UILabel!
    
    @IBOutlet weak var imageView: UIImageView!
    
    var fahren = ""
    var kelvin = ""
    var text = ""
    var image = ""
    var images = ["freezing","hot","cold","boilinghot","pleasentweather"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fahrenheitLabel.text = fahrenheitLabel.text! + fahren
        kelvinLabel.text = kelvinLabel.text! + kelvin
        textLabel.text = textLabel.text! + text
        animateImage(image)
        imageView.image  = UIImage(named: image)
       
        func animateImage(_ imageName: String){
               //The image is hidden or opaque
               UIView.animate(withDuration: 0, animations: {
                   self.imageView.alpha = 0.0
                   
               })
               
           
               //Image will appear with the given duration
        
       
            
            UIView.animate(withDuration: 1, delay: 0.2, animations: { [self] in
                      self.imageView.alpha = 1.0
                      self.imageView.image = UIImage(named:image)
                  })
            var w =  imageView.frame.width
                    w += 40
                    var h = imageView.frame.height
                    h += 40
                    
                   var x =  imageView.frame.origin.x-20
                    
                    var y = imageView.frame.origin.y-20
                    
                    var largerFrame = CGRect(x: x, y: y, width: w, height: h)
            UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: -1, initialSpringVelocity: 0.1, animations: { [self] in
                self.imageView.frame = largerFrame
                   })
           }
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
