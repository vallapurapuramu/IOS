//
//  ViewController.swift
//  DisplayApp
//
//  Created by student on 9/21/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var ImageDisplay: UIImageView!
    
    
    
    
    @IBOutlet weak var crsNum: UILabel!
    
    
    @IBOutlet weak var crsTitle: UILabel!
    
    
    @IBOutlet weak var NextButton: UIButton!
    @IBOutlet weak var PrevButton: UIButton!
    
    var i = 0;
    var courses = [["44555","Network Security","fall","img01"],["44643","Mobile Edge Computing","spring","img02"],["44443","Data Streaming","fall","img03"]]
    @IBOutlet weak var crsSem: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        PrevButton.isEnabled = false
        crsNum.text = courses[0][0]
        crsTitle.text=courses[0][1]
        crsSem.text = courses[0][2]
        ImageDisplay.image = UIImage(named: courses[0][3])
        
    }

    @IBAction func PreviouButton(_ sender: UIButton) {
        NextButton.isEnabled=true;
               if(i-1 < courses.count){
                   i-=1;
                updateData(i);
               }
               
               if(i == 0){
                   PrevButton.isEnabled=false;
               }
              
    }
    
    @IBAction func NextButton(_ sender: UIButton) {
        
        PrevButton.isEnabled=true;
               if(i+1 < courses.count){
                   i+=1;
                updateData(i);
               
               }
               
               if(i+1 == courses.count){
                   NextButton.isEnabled=false;
               }
               
    }
    
    func updateData(_ imgNumber:Int)
    {
        crsNum.text=courses[i][0];
           crsTitle.text=courses[i][1];
           crsSem.text=courses[i][2];
           ImageDisplay.image=UIImage(named: courses[i][3]);
    }
}

