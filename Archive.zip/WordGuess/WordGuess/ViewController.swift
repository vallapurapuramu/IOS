//
//  ViewController.swift
//  WordGuess
//
//  Created by student on 9/30/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var DisplayLabel:UILabel!
       
       
       @IBOutlet weak var HintLabel: UILabel!
       
       
       @IBOutlet weak var StatusLabel: UILabel!
       
       @IBOutlet weak var TextEnter: UITextField!
       
       @IBOutlet weak var ButtonChecked: UIButton!
       @IBOutlet weak var PlayAgainAction: UIButton!
       
       var words = [["SWIFT", "Programming Language"],
                    ["DOG", "Animal"],
                    ["CYCLE", "Two wheeler"],
                    ["MACBOOK", "Apple device"]]
       
       var count = 0;
           var word = ""
           var lettersGuessed = ""
       
       
       override func viewDidLoad() {
           super.viewDidLoad()
           // Do any additional setup after loading the view.
           ButtonChecked.isEnabled = false;
           word = words[count][0]
                   DisplayLabel.text = ""
                   for letter in word{
                       DisplayLabel.text! += "- "
                   }
                   HintLabel.text = "Hint: "+words[count][1]
                   StatusLabel.text = ""
           
       }

      
    @IBAction func TextBox(_ sender: UITextField) {
        
       
            var TextEnterd = TextEnter.text!;
                   TextEnterd = String(TextEnterd.last ?? " ").trimmingCharacters(in: .whitespaces)
                   TextEnter.text = TextEnterd
                   
                   if TextEnterd.isEmpty{
                       ButtonChecked.isEnabled = false
                   }
                   else{
                       ButtonChecked.isEnabled = true
                   }
            
        
    }
    
       @IBAction func CheckButton(_ sender: Any) {
           var letter = TextEnter.text!
                   lettersGuessed = lettersGuessed + letter
                    var revealedWord = ""
                   for l in word{
                       if lettersGuessed.contains(l){
                           revealedWord += "\(l)"
                       }
                       else{
                           revealedWord += "_ "
                       }
                   }
                   DisplayLabel.text = revealedWord
                   TextEnter.text = ""
                   
                   if DisplayLabel.text!.contains("_") == false{
                       PlayAgainAction.isHidden = false;
                       ButtonChecked.isEnabled = false;
                   }
           
       }
       @IBAction func PlayButtonClicked(_ sender: UIButton) {
           PlayAgainAction.isHidden = true
               
                  lettersGuessed = ""
                  count += 1
                  if count == words.count{
                      
                      StatusLabel.text = "Congruations! You are done with the game!"
                  }
                  else{
                  word = words[count][0]
                  HintLabel.text = "Hint: "
                  HintLabel.text! += words[count][1]
                  ButtonChecked.isEnabled = true
                  
                  DisplayLabel.text = ""
                  updateUnderscores()
                  }
       }
       func updateUnderscores(){
               for letter in word{
                   DisplayLabel.text! += "- "
               }
           }
       
       
       
   }
