//
//  ProductsDisplayViewController.swift
//  Vallapurapu_TableViewDisplay
//
//  Created by student on 11/19/21.
//

import UIKit

class ProductsDisplayViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return resArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = productsTableView.dequeueReusableCell(withIdentifier: "showProducts", for: indexPath)
        cell.textLabel?.text = resArray[indexPath.row]
        return cell
    }
    

    @IBOutlet weak var productsTableView: UITableView!
    
    var detailList : String?
    
    var cars = ["Ram", "Lambo" ,"Honda" ,"Benz" ,"Tesla"]
    var fruits = ["Apple","Strawberry","Banana","Mango","Watermelon"]
    var electronicItems = ["Camera","Headset","Mobile","Laptop","SmartWatch"]
    var resArray = [String]()
    var itemName = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        productsTableView.delegate = self
        productsTableView.dataSource = self
        if detailList == "Cars"
        {
            resArray = cars
            itemName = "cars"
        }
        else if detailList == "Fruits"{
            resArray = fruits
            itemName = "fruits"
        }
        else{
            resArray = electronicItems
            itemName = "elec"
        }
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "displayImages"{
            let destination = segue.destination as! DisplayImagesViewController
            destination.imageName = resArray[(productsTableView.indexPathForSelectedRow?.row)!]
            destination.itemName = itemName
        }
    }
    

}
