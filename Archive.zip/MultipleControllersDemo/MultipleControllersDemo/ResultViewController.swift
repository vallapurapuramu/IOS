//
//  ResultViewController.swift
//  MultipleControllersDemo
//
//  Created by student on 10/19/21.
//

import UIKit

class ResultViewController: UIViewController {

    @IBOutlet weak var EnteredAmount: UILabel!
    
    
    
    @IBOutlet weak var EnteredDisc: UILabel!
    
    
    @IBOutlet weak var PriceAfterDisc: UILabel!
    
    
    var amount = ""
    var discRate = ""
    var priceaftrdiscount = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        
        EnteredAmount.text = EnteredAmount.text!+amount
        EnteredDisc.text = EnteredDisc.text!+discRate
        PriceAfterDisc.text = PriceAfterDisc.text!+priceaftrdiscount

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
