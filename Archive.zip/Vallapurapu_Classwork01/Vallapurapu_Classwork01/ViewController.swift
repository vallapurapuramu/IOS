//
//  ViewController.swift
//  Vallapurapu_Classwork01
//
//  Created by student on 10/14/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var amountLabel: UITextField!
    
    @IBOutlet weak var DiscountLabel: UITextField!
    @IBOutlet weak var resultLabel: UILabel!
    
    @IBOutlet weak var label2: UILabel!
    @IBOutlet weak var label1: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func discountButton(_ sender: UIButton) {
        label1.text = "The eneterd amount is  $ \(amountLabel.text!)"
        label2.text = "The entered discount is $ \(DiscountLabel.text!)"
         var enteredamount = Double(amountLabel.text!) ?? 0.0
        var entereddiscount =  Double(DiscountLabel.text!) ?? 0.0
        

        
    var discountedvalue =   entereddiscount/100 * enteredamount
        var result = enteredamount - discountedvalue
    
     resultLabel.text = "Price after discount is $ \(result)"
        amountLabel.text = ""
        DiscountLabel.text = ""
        amountLabel.becomeFirstResponder()
        
                       
        
    
        
                                        
        
       
        
    }
    
}

