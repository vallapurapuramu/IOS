//
//  AutoCompleteSearchResponse.swift
//  Food and Recipe
//
//  Created by student on 11/10/21.
//

import Foundation

struct AutoCompleteSearchResponse: Codable {
    let id: Int
    let title: String
}
