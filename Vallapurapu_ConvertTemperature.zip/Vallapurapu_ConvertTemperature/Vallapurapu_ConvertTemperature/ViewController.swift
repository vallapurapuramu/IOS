//
//  ViewController.swift
//  Vallapurapu_ConvertTemperature
//
//  Created by student on 11/3/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tempTextField: UITextField!
    
    @IBOutlet weak var convertButton: UIButton!
    var fahren = 0.0
        var kelvin = 0.0
        var images = ["freezing","hot","cold","boilinghot","pleasentweather"]
        override func viewDidLoad() {
            super.viewDidLoad()
            convertButton.isEnabled = false
           
            // Do any additional setup after loading the view.
        }


     
           override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
                let transition = segue.identifier
                if transition == "convertTemp"{
                    let destination = segue.destination as! ResultViewController
                    let a = Double(tempTextField.text!)!
                    let c = (a * 9/5) + 32
                     let d = c * 100
                    let e = (d.rounded())/100

                    var fahren = e
                    let b = Double(tempTextField.text!)!
                    var kelvin = b + 273.15
                    destination.fahren = String(fahren)
                    destination.kelvin = String(kelvin)
                    if (a < 5) {
                        destination.text = "It is freezing outside,Please dont come out"
                        destination.image = String(images[0])
                    }
                    else if( a>=5 && a<=59){
                        destination.text = "Please be carefull it is cold"
                        destination.image = String(images[2])
                    }
                    else if(a>=60 && a<=77){
                        destination.text = "There is a pleasant weather outside"
                        destination.image = String(images[4])
                    }
                    else if(a>=78 && a<=95){
                        destination.text = "Its hot outside,wear light clothes"
                        destination.image = String(images[1])
                    }
                    else if(a>95){
                        destination.text = "Its boiling hot, put in your "
                        destination.image = String(images[3])
                    }
                    //destination.priceAfterDiscount = String(priceAfterDiscount)
                    
                }
               
            }
        
        
        @IBAction func editingChanged(_ sender: Any) {
           
            
            var isInt = Double(tempTextField.text!)
            if isInt != nil{
                convertButton.isEnabled = true
            }
            else{
                convertButton.isEnabled = false
            }
        }
           
    }
