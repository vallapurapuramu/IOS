import UIKit

var greeting = "Hello, playground"

class Circle{
    var radius : Double
    init() {
        radius = 20
    }
    init(_ radius:Double)
    {
        self.radius = radius
    }
    func getArea()-> Double
    {
        return Double.pi*radius*radius
    }
    func getPerimeter() -> Double {
        return 2*Double.pi*radius
    }
}
let C1 = Circle()
print(C1.getArea())
print(C1.getPerimeter())
