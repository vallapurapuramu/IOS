//
//  ViewController.swift
//  MultipleControllersDemo
//
//  Created by student on 10/19/21.
//

import UIKit

class HomeViewController: UIViewController {

 
    @IBOutlet weak var amountOutlet: UITextField!
    
    
    @IBOutlet weak var DiscountOutlet: UITextField!
    
    var cal = 0.0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func CalcButton(_ sender: UIButton) {
        
        let amount = Double(amountOutlet.text!)
        let discount = Double(DiscountOutlet.text!)
        print(amount ?? 0.0)
        print(discount ?? 0.0)
        
        cal = amount! - (amount!*discount!/100)
        
        print(cal)
        
 
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transistion = segue.identifier
        if transistion == "ResultSegue"
        {
            let destination = segue.destination
            as!
            ResultViewController
            destination.amount =  amountOutlet.text!
            destination.discRate = DiscountOutlet.text!
            destination.priceaftrdiscount = String(cal)
        }
    }
}

