import UIKit

var greeting = "Hello, playground"

class Animal{
    var breed : String
    var age : Int
    
    init(breed:String, age:Int) {
        self.age = age
        self.breed = breed
    }
    func wakeUpAnimal()
    {
        print("Dont wake up the animal")
    }
    func getAnimalDetails() ->  String {
        return "Animal Breed: \(breed),\nAnimal Age: \(age)" }
    
    
}
class Dog:  Animal {
    var DogType:String
    init(DogType:String) {
        
        self.DogType = DogType
        super.init(breed: "PUG", age: 2)
    }
    override func wakeUpAnimal() {
        print("Tap the Animal to wakeup")
    }
    override func getAnimalDetails() -> String {
        return super.getAnimalDetails()+"\nDog type: \(DogType)"
    }
}
let D = Dog(DogType: "Home Purpose")
D.wakeUpAnimal()
print(D.getAnimalDetails())
